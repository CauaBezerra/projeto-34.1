
const Engine = Matter.Engine;
const World = Matter.World;
const Bodies = Matter.Bodies;
const Body = Matter.Body;

var solo;
var bola;

function preload(){
  
}

function setup() {
  createCanvas(400,400);

  engine = Engine.create();
  world = engine.world;

  var solo_options = {
    isStatic:true
  };
  solo = Bodies.rectangle(width/2,height-20,width,10,solo_options);

  bola = new Bola(100,300);
  
}


function draw() 
{
  background(51);
  Engine.update(engine);

  push();
  rectMode(CENTER);
  rect(solo.position.x,solo.position.y,width,10);
  pop();

  bola.display();
  
}

